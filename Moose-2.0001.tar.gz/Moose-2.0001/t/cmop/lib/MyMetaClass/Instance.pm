
package MyMetaClass::Instance;

use strict;
use warnings;

use base 'Class::MOP::Instance';

1;
