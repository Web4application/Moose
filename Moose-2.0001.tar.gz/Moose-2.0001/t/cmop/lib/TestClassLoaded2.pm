package TestClassLoaded2;
use strict;
use warnings;

our $VERSION = 42;

1;

